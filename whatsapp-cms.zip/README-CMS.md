# WhatsApp Marketing CMS — frontend-only build

## Install & run

```bash
npm install          # installs the new lucide-react dependency
npm run dev
```

Open http://localhost:3000 — it redirects to `/login`.

## Demo login (frontend only)

| Role | User ID | Password |
|---|---|---|
| Super Admin | `superadmin` | `demo123` |
| Client Admin | `clientdemo` | `demo123` |

Credentials are checked in the browser only (`lib/auth.tsx`). There is no backend,
database, real authentication, Meta API, or message sending anywhere in this project.

## Folder structure

```
app/
  layout.tsx            root layout + AuthProvider
  page.tsx              redirects to /login
  globals.css           Tailwind v4 entry
  login/page.tsx        login page
  (app)/layout.tsx      protected shell (sidebar + topbar), redirects to /login if signed out
  (app)/dashboard       role-aware dashboard
  (app)/clients         super admin: clients management
  (app)/subscriptions   subscriptions (super admin = all, client = own)
  (app)/whatsapp-setup  WhatsApp account setup
  (app)/contacts        contacts
  (app)/contacts/import contact import / fetcher
  (app)/templates       templates
  (app)/bulk-sender     bulk message sender
  (app)/campaigns       campaigns + create wizard
  (app)/queue           queue & rate limiting
  (app)/message-status  message status
  (app)/reports         reports & analytics
  (app)/inbox           WhatsApp inbox / live chat
  (app)/consent         consent & opt-out
  (app)/settings        settings
components/layout/      AppLayout, Sidebar, MobileSidebar, Topbar
components/ui/          shared UI kit (DataTable, Modal, Drawer, InlineAlert, etc.)
components/dashboard/   SuperAdminDashboard, ClientAdminDashboard
components/forms/       ClientForm, ContactForm
components/subscription/ PlanCard, PlanComparison, CheckoutModal, SubscriptionBadge,
                        SubscriptionHistoryTable, TrialReminder, AccessGate
components/templates/   TemplateBuilder, TemplatePreview, TemplateSourceBadge
lib/                    auth, nav config, utils, subscription/customTemplates/campaign stores
data/                   mock data only (incl. plans.ts)
types/                  shared TypeScript types
```

## Subscriptions & free trial

- Every new client account starts on a **14-day free CMS trial**. The Clients form
  pre-fills the trial window, and the Subscription page shows the trial start
  date, expiry date, and remaining days.
- Status badges are derived from the expiry date at runtime (never hardcoded):
  `Free Trial`, `Active`, `Expiring Soon` (≤ 3 days), `Expired`, `Suspended`.
- The Topbar shows a compact reminder for Client Admins only — "Your free trial
  expires in X days" / "…expires today" / "Your plan has expired" / "Your plan
  expires in X days". Clicking it opens the Subscription page.
- Three annual plans: Starter ₹2,999, Growth ₹7,999, Business ₹14,999. Feature
  limits shown are indicative and can be configured later by Super Admin.
- Once a trial or plan lapses, paid CMS pages render a "Subscription Expired"
  screen (`components/subscription/AccessGate.tsx`). Dashboard, Subscription, and
  Settings stay reachable so the client can always pick a plan.
- The checkout is **simulated** — there is no payment gateway. A success message
  only appears after the demo flow is completed.
- The Subscription page has a **Demo controls** card for previewing each trial
  state (new trial / expiring soon / expires today / expired / reset).

## Custom templates

- Templates page has three tabs: All Templates, Meta-Approved Templates, Custom
  Templates. Custom templates are scoped to the signed-in client and are never
  labelled "Meta Approved".
- The builder supports text, image/video/document media, header/footer, message
  variables ({{1}}, {{2}} …), URL buttons, WhatsApp chat buttons, a live preview,
  Save as Draft, and Save Template. Drafts are not sendable.

## Demo state & isolation

- Subscriptions, custom templates, and campaigns live in React context providers
  under `lib/`, persisted to `localStorage` (keys prefixed `wacms.demo.`).
- Every store filters and guards by `clientId`, so a Client Admin only ever sees
  and mutates their own data. Seed data deliberately includes a second client's
  template and campaign to make the isolation visible.
- To reset everything, use "Reset demo data" on the Subscription page or clear
  `localStorage` for the site.

## Notes

- Sidebar items change by role; every item links to a real page.
- Sidebar collapses on desktop and opens as a drawer on mobile.
- `tsconfig.json` sets `"@/*": ["./*"]` — keep that alias if you replace the file.
- Charts are drawn with plain CSS (`components/ui/ChartCard.tsx`), so no chart library is needed.
- Page titles, breadcrumbs, and the active sidebar item all come from `pageMeta`
  in `lib/nav.ts` — no page hardcodes its own title.
- `lib/auth.tsx` reports one pre-existing `react-hooks/set-state-in-effect` lint
  error. It is a false positive: the session must hydrate in an effect to avoid
  an SSR hydration mismatch. This error predates the subscription/template work.
