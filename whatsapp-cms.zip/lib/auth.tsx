"use client";

import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useState,
} from "react";
import type { Role, User } from "@/types";

const STORAGE_KEY = "wacms.demo.user";

/**
 * Demo accounts. Frontend-only — no backend, no real authentication.
 */
const DEMO_USERS: (User & { password: string })[] = [
  {
    id: "u1",
    userId: "superadmin",
    password: "demo123",
    name: "Priya Menon",
    email: "priya@whatsappcms.test",
    role: "super_admin",
  },
  {
    id: "u2",
    userId: "clientdemo",
    password: "demo123",
    name: "Rahul Verma",
    email: "demo@whatsappcms.test",
    role: "client_admin",
    clientId: "c6",
    clientName: "Demo Client Account",
  },
];

interface AuthContextValue {
  user: User | null;
  ready: boolean;
  login: (userId: string, password: string, remember: boolean) => User | null;
  logout: () => void;
}

const AuthContext = createContext<AuthContextValue | null>(null);

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [ready, setReady] = useState(false);

  useEffect(() => {
    try {
      const raw =
        window.localStorage.getItem(STORAGE_KEY) ??
        window.sessionStorage.getItem(STORAGE_KEY);
      if (raw) setUser(JSON.parse(raw) as User);
    } catch {
      // ignore malformed storage
    }
    setReady(true);
  }, []);

  const login = useCallback(
    (userId: string, password: string, remember: boolean) => {
      const match = DEMO_USERS.find(
        (u) =>
          u.userId.toLowerCase() === userId.trim().toLowerCase() &&
          u.password === password
      );
      if (!match) return null;

      const { password: _pw, ...safeUser } = match;
      void _pw;
      setUser(safeUser);
      try {
        const store = remember ? window.localStorage : window.sessionStorage;
        store.setItem(STORAGE_KEY, JSON.stringify(safeUser));
      } catch {
        // storage unavailable — session stays in memory only
      }
      return safeUser;
    },
    []
  );

  const logout = useCallback(() => {
    setUser(null);
    try {
      window.localStorage.removeItem(STORAGE_KEY);
      window.sessionStorage.removeItem(STORAGE_KEY);
    } catch {
      // ignore
    }
  }, []);

  const value = useMemo(
    () => ({ user, ready, login, logout }),
    [user, ready, login, logout]
  );

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error("useAuth must be used inside <AuthProvider>");
  return ctx;
}

export function roleLabel(role: Role) {
  return role === "super_admin" ? "Super Admin" : "Client Admin";
}

/**
 * The client a user is scoped to. Super Admins return null — they are not
 * limited to a single client's data.
 */
export function clientIdFor(user: User | null) {
  if (!user || user.role === "super_admin") return null;
  return user.clientId ?? null;
}
