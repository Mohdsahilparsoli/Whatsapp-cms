# WhatsApp Marketing CMS

**Phase 1 status:** the Client module (Super Admin ⇄ Clients page) and Client
Admin login now run on a real PostgreSQL database. Everything else (contacts,
templates, campaigns, subscriptions, etc.) is still frontend-only /
`localStorage`, same as before. See **README-BACKEND.md** for full backend
setup instructions (Postgres, Prisma, environment variables).

## Install & run

```bash
npm install                # installs deps + runs `prisma generate`
cp .env.example .env       # then edit .env with your local Postgres credentials
npx prisma migrate dev     # creates the clients/sessions tables (+ seeds demo clients)
npm run dev
```

Open http://localhost:3000 — it redirects to `/login`. Full details, including
what to do if `prisma migrate dev` fails, are in **README-BACKEND.md**.

## Demo login

| Role | User ID | Password | Backed by |
|---|---|---|---|
| Super Admin | `superadmin` | `demo123` | Hardcoded (frontend-only — Phase 2 will add real Super Admin auth) |
| Client Admin (any seeded client) | e.g. `sharma_admin`, `clientdemo` | `Demo@123` | **Real** — PostgreSQL, bcrypt-hashed |

Super Admin credentials are still checked in the browser only (`lib/auth.tsx`).
Client Admin credentials are checked against the database — see
README-BACKEND.md for the full list of seeded clients, and for how to create
new ones from the Clients page (Super Admin → Add client).

## Folder structure

```
app/
  layout.tsx            root layout + AuthProvider
  page.tsx               redirects to /login
  globals.css            Tailwind v4 entry
  login/page.tsx         login page
  api/auth/               login, logout, session, change-password (real, DB-backed)
  api/clients/            client CRUD, status, reset-password (real, DB-backed)
  (app)/layout.tsx       protected shell (sidebar + topbar), redirects to /login if signed out
  (app)/dashboard        role-aware dashboard
  (app)/clients          super admin: clients management — now backed by PostgreSQL
  (app)/subscriptions    subscriptions (super admin = all, client = own)
  (app)/whatsapp-setup   WhatsApp account setup
  (app)/contacts         contacts
  (app)/contacts/import  contact import / fetcher
  (app)/templates        templates
  (app)/bulk-sender      bulk message sender
  (app)/campaigns        campaigns + create wizard
  (app)/queue            queue & rate limiting
  (app)/message-status   message status
  (app)/reports          reports & analytics
  (app)/inbox            WhatsApp inbox / live chat
  (app)/consent          consent & opt-out
  (app)/settings         settings — Password tab is real for Client Admin
components/layout/      AppLayout, Sidebar, MobileSidebar, Topbar
components/ui/          shared UI kit (DataTable, Modal, Drawer, InlineAlert, etc.)
components/dashboard/   SuperAdminDashboard, ClientAdminDashboard
components/forms/       ClientForm, ContactForm
components/subscription/ PlanCard, PlanComparison, CheckoutModal, SubscriptionBadge,
                        SubscriptionHistoryTable, TrialReminder, AccessGate
components/templates/   TemplateBuilder, TemplatePreview, TemplateSourceBadge
lib/                    auth (hybrid: demo Super Admin + real Client Admin),
                        db (Prisma client), session (login cookie), passwords
                        (bcrypt), nav config, utils, subscription/customTemplates/
                        campaignStore (still localStorage — not yet migrated)
prisma/                 schema.prisma (Client, Session), seed.mjs
data/                   mock data for modules not yet migrated to the database
types/                  shared TypeScript types
```

## Subscriptions & free trial

- Every new client account starts on a **14-day free CMS trial**. The Clients form
  pre-fills the trial window, and the Subscription page shows the trial start
  date, expiry date, and remaining days.
- Status badges are derived from the expiry date at runtime (never hardcoded):
  `Free Trial`, `Active`, `Expiring Soon` (≤ 3 days), `Expired`, `Suspended`.
- The Topbar shows a compact reminder for Client Admins only — "Your free trial
  expires in X days" / "…expires today" / "Your plan has expired" / "Your plan
  expires in X days". Clicking it opens the Subscription page.
- Three annual plans: Starter ₹2,999, Growth ₹7,999, Business ₹14,999. Feature
  limits shown are indicative and can be configured later by Super Admin.
- Once a trial or plan lapses, paid CMS pages render a "Subscription Expired"
  screen (`components/subscription/AccessGate.tsx`). Dashboard, Subscription, and
  Settings stay reachable so the client can always pick a plan.
- The checkout is **simulated** — there is no payment gateway. A success message
  only appears after the demo flow is completed.
- The Subscription page has a **Demo controls** card for previewing each trial
  state (new trial / expiring soon / expires today / expired / reset).

## Custom templates

- Templates page has three tabs: All Templates, Meta-Approved Templates, Custom
  Templates. Custom templates are scoped to the signed-in client and are never
  labelled "Meta Approved".
- The builder supports text, image/video/document media, header/footer, message
  variables ({{1}}, {{2}} …), URL buttons, WhatsApp chat buttons, a live preview,
  Save as Draft, and Save Template. Drafts are not sendable.

## Demo state & isolation

- Subscriptions, custom templates, and campaigns live in React context providers
  under `lib/`, persisted to `localStorage` (keys prefixed `wacms.demo.`).
- Every store filters and guards by `clientId`, so a Client Admin only ever sees
  and mutates their own data. Seed data deliberately includes a second client's
  template and campaign to make the isolation visible.
- To reset everything, use "Reset demo data" on the Subscription page or clear
  `localStorage` for the site.

## Client module & authentication (real, Phase 1)

- Client records live in **PostgreSQL** (`clients` table via Prisma). Super
  Admin's Clients page (Create / Edit / Suspend / Activate / Reset password)
  reads and writes the database through `app/api/clients/*`.
- Client Admin login is real: `POST /api/auth/login` checks the database and
  a bcrypt password hash, then sets an httpOnly session cookie. A client
  Super Admin creates can sign in immediately with the User ID and password
  given at creation.
- Client Admin can change their own password from **Settings → Password**
  (`POST /api/auth/change-password`) — the current password must match before
  a new one is accepted.
- **Known gap (by design, for this phase):** Super Admin login is still a
  hardcoded, frontend-only demo account — it is not backed by the database.
  The `/api/clients/*` endpoints only reject calls from a signed-in *Client*
  session; they do not yet verify a real Super Admin session, because none
  exists yet. Do not deploy this publicly until Phase 2 adds real Super Admin
  auth + role checks on these routes. See README-BACKEND.md, "Known gaps".

## Notes

- Sidebar items change by role; every item links to a real page.
- Sidebar collapses on desktop and opens as a drawer on mobile.
- `tsconfig.json` sets `"@/*": ["./*"]` — keep that alias if you replace the file.
- Charts are drawn with plain CSS (`components/ui/ChartCard.tsx`), so no chart library is needed.
- Page titles, breadcrumbs, and the active sidebar item all come from `pageMeta`
  in `lib/nav.ts` — no page hardcodes its own title.
