# Backend setup (Phase 1)

This app's backend runs **inside Next.js itself** — API routes under
`app/api/`, using [Prisma](https://www.prisma.io) to talk to PostgreSQL.
There is no separate Node/Express server: `npm run dev` starts the frontend
*and* the backend together.

## Prerequisites

- Node.js 18.18+ (whatever `next dev` already needs)
- PostgreSQL **18**, already installed on your system, running locally
  (default host `localhost`, default port `5432`)

## 1. Configure the database connection

```bash
cp .env.example .env
```

Open `.env` and set `DATABASE_URL` to your real local Postgres credentials:

```
DATABASE_URL="postgresql://USERNAME:PASSWORD@localhost:5432/whatsapp_cms?schema=public"
```

- `USERNAME` / `PASSWORD` — whatever you set up when you installed Postgres
  (often `postgres` / the password you chose during install).
- `whatsapp_cms` — the database name. It does **not** need to exist yet —
  Prisma's migration step below can create it for you, *if* the Postgres
  user has permission to create databases. If it doesn't, create an empty
  database called `whatsapp_cms` yourself first (e.g. with `psql` or
  pgAdmin), then re-run the migrate command.

## 2. Install dependencies

```bash
npm install
```

This also runs `prisma generate` automatically (via the `postinstall`
script), which generates the typed Prisma Client used throughout `lib/` and
`app/api/`.

## 3. Create the tables

```bash
npx prisma migrate dev
```

This will:
1. Create the `clients` and `sessions` tables (see `prisma/schema.prisma`).
2. Automatically run `prisma/seed.mjs`, which inserts 6 demo clients so you
   have something to log in with right away (see table below).

If you ever want to re-seed without a fresh migration:

```bash
npm run db:seed
```

## 4. Run it

```bash
npm run dev
```

Open http://localhost:3000/login.

## Seeded demo clients

| Client | User ID | Password | Status |
|---|---|---|---|
| Sharma Electronics | `sharma_admin` | `Demo@123` | Active |
| Nova Fashion House | `nova_admin` | `Demo@123` | Active |
| Green Leaf Organics | `greenleaf` | `Demo@123` | Active |
| Apex Fitness Studio | `apexfit` | `Demo@123` | Expired |
| Bluewave Travels | `bluewave` | `Demo@123` | Suspended (login blocked) |
| Demo Client Account | `clientdemo` | `Demo@123` | Active |

Super Admin is still the frontend-only demo account: `superadmin` / `demo123`
(see "Known gaps" below).

Create additional clients from **Super Admin → Clients → Add client** — the
User ID and password you type there work immediately, no re-seeding needed.

## What's real vs. still a demo

| Area | Backed by |
|---|---|
| Client CRUD (create/edit/suspend/activate) | ✅ PostgreSQL, via `app/api/clients/*` |
| Client Admin login | ✅ PostgreSQL + bcrypt password hash + httpOnly session cookie |
| Client Admin "change my password" (Settings) | ✅ PostgreSQL, verifies current password first |
| Super Admin login | ⚠️ Still hardcoded/frontend-only (`lib/auth.tsx`) |
| Contacts, Templates, Campaigns, Bulk Sender, Inbox, Consent, Reports, Subscriptions, WhatsApp Setup | ⚠️ Still frontend-only / `localStorage` — not in this phase's scope |

## Known gaps (by design — read before deploying anywhere real)

This is Phase 1 of an agreed multi-phase plan. On purpose, it does **not**
yet include:

1. **Real Super Admin authentication.** `app/api/clients/*` currently only
   checks "is the caller *not* a signed-in Client Admin" — it cannot yet
   verify "is the caller actually Super Admin", because Super Admin has no
   database-backed session to check. Anyone who is not logged in as a client
   can currently call these endpoints. Phase 2 should add a real Super Admin
   login (its own table, or a `role` column with a shared `AdminUser`
   table) and a proper role check in these routes.
2. **No rate limiting / brute-force protection** on `/api/auth/login`.
3. **No audit log** of who created/edited/suspended which client.
4. Every other module (contacts, templates, campaigns, etc.) is still
   `localStorage`-based and has none of the above considerations yet either
   — they're simply out of scope for this phase.
5. `lib/customTemplates.tsx` and `lib/campaignStore.tsx` still seed a couple
   of sample rows against the **old** demo client ID (`"c6"`, from
   `data/clients.ts`). A real client created via the Clients page gets a
   different (database-generated) ID, so those specific sample rows won't
   show up for them — this is expected for now and will sort itself out once
   those modules move to the database in a later phase.

## Troubleshooting

**`prisma migrate dev` fails to connect** — double-check `DATABASE_URL` in
`.env`: right username/password, Postgres actually running, and the port
matches what you installed (`5432` unless you changed it). On Windows, you
can confirm Postgres is running via the "Services" app (look for
`postgresql-x64-18`) or:
```bash
pg_isready -h localhost -p 5432
```

**`permission denied to create database`** — your Postgres user isn't
allowed to create new databases. Create `whatsapp_cms` yourself first (e.g.
`CREATE DATABASE whatsapp_cms;` in `psql` or pgAdmin), then re-run
`npx prisma migrate dev`.

**`prisma generate` fails to download engine files** — this happens if your
network blocks `binaries.prisma.sh`. It should work fine on a normal
internet connection; if you're behind a restrictive corporate proxy/firewall,
allow that domain or see Prisma's docs on custom engine mirrors.

**Changed `prisma/schema.prisma` and want a fresh migration** — run
`npx prisma migrate dev` again; Prisma will generate a new migration file
and prompt you if it needs to.

**Want to inspect the database visually** — `npm run db:studio` opens
Prisma Studio (a local GUI) at http://localhost:5555.
