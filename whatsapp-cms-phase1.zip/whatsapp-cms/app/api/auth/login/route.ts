import { NextResponse } from "next/server";
import { prisma } from "@/lib/db";
import { verifyPassword } from "@/lib/passwords";
import { createSession, toPublicClient } from "@/lib/session";

/**
 * Client Admin login. Super Admin is NOT handled here — that login stays a
 * hardcoded, frontend-only demo account for now (see lib/auth.tsx / the
 * project's agreed Phase 1 scope).
 */
export async function POST(request: Request) {
  let body: { userId?: string; password?: string };
  try {
    body = await request.json();
  } catch {
    return NextResponse.json({ error: "Invalid request body." }, { status: 400 });
  }

  const userId = body.userId?.trim();
  const password = body.password ?? "";
  if (!userId || !password) {
    return NextResponse.json({ error: "User ID and password are required." }, { status: 400 });
  }

  const client = await prisma.client.findFirst({
    where: { userId: { equals: userId, mode: "insensitive" } },
  });

  if (!client) {
    return NextResponse.json({ error: "Invalid User ID or password." }, { status: 401 });
  }

  const passwordOk = await verifyPassword(password, client.passwordHash);
  if (!passwordOk) {
    return NextResponse.json({ error: "Invalid User ID or password." }, { status: 401 });
  }

  if (client.status === "suspended") {
    return NextResponse.json(
      { error: "This account has been suspended by Super Admin. Contact them to reactivate it." },
      { status: 403 }
    );
  }

  await createSession(client.id);

  return NextResponse.json({ client: toPublicClient(client) });
}
