import { NextResponse } from "next/server";
import { getSessionClient } from "@/lib/session";

export async function GET() {
  const client = await getSessionClient();
  return NextResponse.json({ client });
}
