import { PrismaClient } from "@prisma/client";

/**
 * Next.js dev mode hot-reloads modules, which would otherwise create a new
 * PrismaClient (and a new DB connection pool) on every file save. Caching the
 * instance on `globalThis` avoids that.
 */
const globalForPrisma = globalThis as unknown as {
  prisma: PrismaClient | undefined;
};

export const prisma = globalForPrisma.prisma ?? new PrismaClient();

if (process.env.NODE_ENV !== "production") globalForPrisma.prisma = prisma;
