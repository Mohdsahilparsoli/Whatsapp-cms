"use client";

import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useState,
} from "react";
import type { Role, User } from "@/types";

const STORAGE_KEY = "wacms.demo.user";

/**
 * Super Admin login. Phase 1 scope: Super Admin auth is still a hardcoded,
 * frontend-only demo account — it is NOT backed by the database yet.
 *
 * Client Admin login is real (see `login()` below): it calls
 * POST /api/auth/login, which checks the `clients` table in PostgreSQL and
 * verifies a bcrypt password hash. Any client Super Admin creates from the
 * Clients page can sign in with the User ID + password they were given.
 */
const DEMO_USERS: (User & { password: string })[] = [
  {
    id: "u1",
    userId: "superadmin",
    password: "demo123",
    name: "Priya Menon",
    email: "priya@whatsappcms.test",
    role: "super_admin",
  },
];

export type LoginResult = { user: User } | { error: string };

interface AuthContextValue {
  user: User | null;
  ready: boolean;
  login: (userId: string, password: string, remember: boolean) => Promise<LoginResult>;
  logout: () => void;
}

const AuthContext = createContext<AuthContextValue | null>(null);

function persist(user: User, remember: boolean) {
  try {
    const store = remember ? window.localStorage : window.sessionStorage;
    store.setItem(STORAGE_KEY, JSON.stringify(user));
  } catch {
    // storage unavailable — session stays in memory only
  }
}

function clearStorage() {
  try {
    window.localStorage.removeItem(STORAGE_KEY);
    window.sessionStorage.removeItem(STORAGE_KEY);
  } catch {
    // ignore
  }
}

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [ready, setReady] = useState(false);

  useEffect(() => {
    let cancelled = false;

    async function hydrate() {
      let stored: User | null = null;
      try {
        const raw =
          window.localStorage.getItem(STORAGE_KEY) ??
          window.sessionStorage.getItem(STORAGE_KEY);
        if (raw) stored = JSON.parse(raw) as User;
      } catch {
        // ignore malformed storage
      }

      if (!stored) {
        if (!cancelled) setReady(true);
        return;
      }

      if (stored.role === "super_admin") {
        // Demo account — no server session to verify.
        if (!cancelled) {
          setUser(stored);
          setReady(true);
        }
        return;
      }

      // Client Admin — the real source of truth is the httpOnly session
      // cookie, not localStorage. Verify it so a suspended/expired session
      // logs the client out instead of showing a stale cached user.
      try {
        const res = await fetch("/api/auth/session");
        const data = await res.json();
        if (!cancelled) {
          if (data.client) {
            setUser({
              id: data.client.id,
              userId: data.client.userId,
              name: data.client.name,
              email: data.client.email,
              role: "client_admin",
              clientId: data.client.id,
              clientName: data.client.name,
            });
          } else {
            clearStorage();
          }
          setReady(true);
        }
      } catch {
        // Network/server unavailable — fall back to the cached user rather
        // than forcing a logout.
        if (!cancelled) {
          setUser(stored);
          setReady(true);
        }
      }
    }

    hydrate();
    return () => {
      cancelled = true;
    };
  }, []);

  const login = useCallback(
    async (userId: string, password: string, remember: boolean): Promise<LoginResult> => {
      const demoMatch = DEMO_USERS.find(
        (u) =>
          u.userId.toLowerCase() === userId.trim().toLowerCase() &&
          u.password === password
      );
      if (demoMatch) {
        const { password: _pw, ...safeUser } = demoMatch;
        void _pw;
        setUser(safeUser);
        persist(safeUser, remember);
        return { user: safeUser };
      }

      try {
        const res = await fetch("/api/auth/login", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ userId, password }),
        });
        const data = await res.json();

        if (!res.ok) {
          return { error: data.error ?? "Invalid User ID or password." };
        }

        const clientUser: User = {
          id: data.client.id,
          userId: data.client.userId,
          name: data.client.name,
          email: data.client.email,
          role: "client_admin",
          clientId: data.client.id,
          clientName: data.client.name,
        };
        setUser(clientUser);
        persist(clientUser, remember);
        return { user: clientUser };
      } catch {
        return { error: "Could not reach the server. Please try again." };
      }
    },
    []
  );

  const logout = useCallback(() => {
    const wasClient = user?.role === "client_admin";
    setUser(null);
    clearStorage();
    if (wasClient) {
      // Best-effort — clears the server-side session row + cookie.
      fetch("/api/auth/logout", { method: "POST" }).catch(() => {});
    }
  }, [user]);

  const value = useMemo(
    () => ({ user, ready, login, logout }),
    [user, ready, login, logout]
  );

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error("useAuth must be used inside <AuthProvider>");
  return ctx;
}

export function roleLabel(role: Role) {
  return role === "super_admin" ? "Super Admin" : "Client Admin";
}

/**
 * The client a user is scoped to. Super Admins return null — they are not
 * limited to a single client's data.
 */
export function clientIdFor(user: User | null) {
  if (!user || user.role === "super_admin") return null;
  return user.clientId ?? null;
}
